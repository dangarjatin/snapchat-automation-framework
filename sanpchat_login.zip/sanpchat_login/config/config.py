class Config:
    APP_PACKAGE = "com.snapchat.android"
    APP_ACTIVITY = "com.snapchat.android.VampireFangsAlias"
    PLATFORM_NAME = "Android"
    DEVICE_NAME = "R5CT91K1G6L"
    APPIUM_SERVER = "http://127.0.0.1:4723/wd/hub"
